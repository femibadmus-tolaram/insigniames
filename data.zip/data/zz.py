# import sqlite3
# from datetime import datetime

# conn = sqlite3.connect("data/local.db")
# cur = conn.cursor()

# machines_data = [
#     ("IBF10001", "BLOWNFL-LINE1"),
#     ("IBF20001", "BLOWNFL-LINE1"),
#     ("IDL10001", "DRY LAM- LINE1"),
#     ("IDL20001", "DRY LAM- LINE2"),
#     ("IDLT0001", "DRY LAM- LINE3"),
#     ("IEX10001", "EXTRUSION-LINE1"),
#     ("IEX20001", "EXTRUSION-LINE2"),
#     ("IIK10001", "INK KITCHEN (PUMPOUT)"),
#     ("IML10001", "METALLISER-LINE1"),
#     ("IPO10001", "POUCH SEMOLINA 10KG"),
#     ("IPO10002", "POUCH- LUSH BRAZIWOOL"),
#     ("IPO10003", "POUCH MOSAIC FOOD YAM FLOUR 1.8KG & 4LB"),
#     ("IPO10004", "POUCH MIKSI 750G CYAN BACKGROUND"),
#     ("IPO10005", "POUCH WOMENEEZZ SANATARY NAPKIN"),
#     ("IPO10006", "POUCH BABYEEZZ NAPPY PANTS"),
#     ("IPO10007", "POUCH SUNBIRD WITH STIFFNER"),
#     ("IPR10001", "PRINTING-LINE1"),
#     ("IPR20001", "PRINTING-LINE2"),
#     ("IPR30001", "PRINTING-LINE3"),
#     ("IPR40001", "PRINTING-LINE4"),
#     ("IRC10001", "RECYCLING"),
# ]

# cur.executemany("INSERT INTO machines (name, label) VALUES (?, ?)", machines_data)

# conn.commit()
# conn.close()

import sqlite3, datetime
conn=sqlite3.connect("data/local.db");cur=conn.cursor()
now=datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")

# cur.executemany("INSERT INTO shifts(name) VALUES(?)",[("Morning",),("Afternoon",),("Night",)])
# cur.executemany("INSERT INTO colours(name) VALUES(?)",[("Red",),("Blue",),("Green",)])
# cur.executemany("INSERT INTO solvent_types(name) VALUES(?)",[("Toluene",),("Ethyl Acetate",)])
# cur.executemany("INSERT INTO scrap_types(name) VALUES(?)",[("Edge Trim",),("Startup Waste",)])
# cur.executemany("INSERT INTO downtime_reasons(name) VALUES(?)",[("Breakdown",),("Cleaning",)])
# cur.executemany("INSERT INTO flag_reasons(name) VALUES(?)",[("Tear",),("Colour Issue",)])

# cur.executemany(
# "INSERT INTO users(full_name,staffid,phone_number,password,status,role_id,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?)",
# [
# ("Operator One","STF001","08011111111","pass","active",1,now,now),
# ("Operator Two","STF002","08022222222","pass","active",1,now,now),
# ]
# )

# cur.executemany(
# "INSERT INTO jobs(shift_id,production_order,batch_roll_no,start_weight,start_meter,created_by,machine_id) VALUES(?,?,?,?,?,?,?)",
# [
# (1,"PO123","BR001",120.5,300.0,1,1),
# (2,"PO124","BR002",150.0,420.0,2,2),
# ]
# )

cur.executemany(
"INSERT INTO downtimes(shift_id,start_time,end_time,duration_minutes,downtime_reason_id,created_by) VALUES(?,?,?,?,?,?)",
[
(1,now,now,30,1,1),
(2,now,now,45,2,2),
(1,now,now,30,1,1),
(2,now,now,45,2,2),
(1,now,now,30,1,1),
(2,now,now,45,2,2),
(1,now,now,30,1,1),
(2,now,now,45,2,2),
(1,now,now,30,1,1),
(2,now,now,45,2,2),
(1,now,now,30,1,1),
(2,now,now,45,2,2),
(1,now,now,30,1,1),
(2,now,now,45,2,2),
(1,now,now,30,1,1),
(2,now,now,45,2,2),
(1,now,now,30,1,1),
(2,now,now,45,2,2),
(1,now,now,30,1,1),
(2,now,now,45,2,2),
(1,now,now,30,1,1),
(2,now,now,45,2,2),
(1,now,now,30,1,1),
(2,now,now,45,2,2),
(1,now,now,30,1,1),
(2,now,now,45,2,2),
]
)

# cur.executemany(
# "INSERT INTO scraps(shift_id,time,scrap_type_id,weight_kg,notes,created_by) VALUES(?,?,?,?,?,?)",
# [
# (1,now,1,12.5,"Startup purge",1),
# (2,now,2,8.0,"Trim waste",2),
# ]
# )

# cur.executemany(
# "INSERT INTO solvent_usages(shift_id,solvent_type_id,kgs_issued,created_by) VALUES(?,?,?,?)",
# [
# (1,1,5.5,1),
# (2,2,7.0,2),
# ]
# )

# cur.executemany(
# "INSERT INTO ink_usages(shift_id,colour_id,batch_code,kgs_issued,created_by) VALUES(?,?,?,?,?)",
# [
# (1,1,"BC001",3.2,1),
# (2,2,"BC002",4.0,2),
# ]
# )

conn.commit();conn.close()

