import sqlite3
import hashlib
import datetime

conn = sqlite3.connect("data/local.db")
cursor = conn.cursor()

cursor.execute("DELETE FROM role_permissions")
cursor.execute("DELETE FROM permissions")
cursor.execute("DELETE FROM content_type")
cursor.execute("DELETE FROM users WHERE staffid = 'T001'")
cursor.execute("DELETE FROM roles WHERE name IN ('Admin', 'User')")
cursor.execute("DELETE FROM user_machines")
cursor.execute("DELETE FROM machines")

models = [
    "users", "roles", "permissions", "jobs", "rolls", "downtimes", "scraps", 
    "ink_usages", "solvent_usages", "shifts", "colours", "solvent_types", 
    "scrap_types", "downtime_reasons", "flag_reasons", "machines"
]

for model in models:
    cursor.execute("INSERT INTO content_type (model) VALUES (?)", (model,))

# Create admin permissions (1,1,1,1)
for model in models:
    cursor.execute("""
        INSERT INTO permissions (codename, name, content_type_id, can_create, can_read, can_update, can_delete)
        SELECT ? || '_admin', 'Admin Access ' || ?, id, 1, 1, 1, 1
        FROM content_type WHERE model = ?
    """, (model, model, model))

# Create user read-only permissions (0,1,0,0)
for model in models:
    cursor.execute("""
        INSERT INTO permissions (codename, name, content_type_id, can_create, can_read, can_update, can_delete)
        SELECT ? || '_read', 'Read Only ' || ?, id, 0, 1, 0, 0
        FROM content_type WHERE model = ?
    """, (model, model, model))

cursor.execute("INSERT INTO roles (name, description) VALUES (?, ?)", ("Admin", "Full system access"))
cursor.execute("INSERT INTO roles (name, description) VALUES (?, ?)", ("User", "Default user role"))

cursor.execute("SELECT id FROM permissions WHERE codename LIKE '%_admin'")
admin_permission_ids = [row[0] for row in cursor.fetchall()]

cursor.execute("SELECT id FROM permissions WHERE codename LIKE '%_read'")
user_permission_ids = [row[0] for row in cursor.fetchall()]

cursor.execute("SELECT id FROM roles WHERE name = 'Admin'")
admin_role_id = cursor.fetchone()[0]

cursor.execute("SELECT id FROM roles WHERE name = 'User'")
user_role_id = cursor.fetchone()[0]

for perm_id in admin_permission_ids:
    cursor.execute("INSERT INTO role_permissions (role_id, permission_id) VALUES (?, ?)", (admin_role_id, perm_id))

for perm_id in user_permission_ids:
    cursor.execute("INSERT INTO role_permissions (role_id, permission_id) VALUES (?, ?)", (user_role_id, perm_id))

password = hashlib.sha256("test123".encode()).hexdigest()
now = datetime.datetime.now()

cursor.execute("""
INSERT INTO users (full_name, staffid, phone_number, password, status, role_id, created_at, updated_at)
VALUES (?, ?, ?, ?, ?, ?, ?, ?)
""", ("Test User", "T001", "0000000000", password, "active", admin_role_id, now, now))

conn.commit()
conn.close()